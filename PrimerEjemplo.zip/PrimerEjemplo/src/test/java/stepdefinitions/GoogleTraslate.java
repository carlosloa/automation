package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleTraslate {


    @Given("^that Carlos want to use Google Traslate$")
    public void thatCarlosWantToUseGoogleTraslate() {

    }


    @When("^he traslate the word table from English to Spanish$")
    public void heTraslateTheWordTableFromEnglishToSpanish() {

    }

    @Then("^he should see the word mesa on the screen$")
    public void heShouldSeeTheWordMesaOnTheScreen() {
        System.out.println();
    }

    

}
